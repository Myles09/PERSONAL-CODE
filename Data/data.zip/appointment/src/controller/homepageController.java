package controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

import java.net.URL;
import java.util.ResourceBundle;

public class homepageController implements Initializable {

    @FXML
    private Button generalHealthConsultationButton;

    @FXML
    private Button prescriptionRefillsButton;

    @FXML
    private Button mentalHealthCounselingButton;

    @FXML
    private Button nutritionDietaryAdviceButton;

    @FXML
    private Button sexualHealthConsultationButton;

    @FXML
    private Label generalHealthDescriptionLabel;

    @FXML
    private Label prescriptionRefillsDescriptionLabel;

    @FXML
    private Label mentalHealthCounselingDescriptionLabel;

    @FXML
    private Label nutritionDietaryAdviceDescriptionLabel;

    @FXML
    private Label sexualHealthConsultationDescriptionLabel;

    @FXML
    private ImageView specialistImage1;
    
    @FXML
    private Label specialistName1;
    
    @FXML
    private ImageView specialistImage2;
    
    @FXML
    private Label specialistName2;

    @FXML
    private ImageView specialistImage3;
    
    @FXML
    private Label specialistName3;
    
    @FXML
    private ImageView specialistImage4;
    
    @FXML
    private Label specialistName4;

    @FXML
    private ImageView specialistImage5;
    
    @FXML
    private Label specialistName5;
    
   

    @Override
    public void initialize(URL location, ResourceBundle resources) {       
        generalHealthConsultationButton.setOnAction(event -> handleGeneralHealthConsultation());
        prescriptionRefillsButton.setOnAction(event -> handlePrescriptionRefills());
        mentalHealthCounselingButton.setOnAction(event -> handleMentalHealthCounseling());
        nutritionDietaryAdviceButton.setOnAction(event -> handleNutritionDietaryAdvice());
        sexualHealthConsultationButton.setOnAction(event -> handleSexualHealthConsultation());
    }

   
    private void handleGeneralHealthConsultation() {
       
    }

    private void handlePrescriptionRefills() {
       
    }

    private void handleMentalHealthCounseling() {
       
    }

    private void handleNutritionDietaryAdvice() {
        
    }

    private void handleSexualHealthConsultation() {
        
    
      
            // Initialize your specialist doctor team section here
            specialistName1.setText("Dr. Emily Rodriguez, MD");
                       
            specialistName2.setText("Dr. Sarah Jones, MD");
            
            specialistName3.setText("Dr. Emily Patel, PsyD");

            specialistName4.setText("Dr. John Mitchell, RD");

            specialistName5.setText("Dr. James Anderson, MD");
                       
        }
    }
       
