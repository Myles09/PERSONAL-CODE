package controller;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;

import java.net.URL;
import java.util.ResourceBundle;

public class firstpageController implements Initializable {

   @FXML
private Button registerNowButton;

@FXML
private TabPane tabPane;

@FXML
private TextArea howItWorksTextArea;

@FXML
private TextArea whyChooseUsTextArea;

@FXML
private TextArea keyFeaturesTextArea;


@Override
public void initialize(URL location, ResourceBundle resources) {
   
    registerNowButton.setOnAction(event -> handleRegisterNowButton());
}

private void handleRegisterNowButton() {
     System.out.println("Register Now button clicked!");
 }
}