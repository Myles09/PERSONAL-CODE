package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class PatientsProfileController {

    @FXML
    private TextField nameField;

    @FXML
    private DatePicker dateOfBirthPicker;

    @FXML
    private CheckBox maleCheckBox;

    @FXML
    private CheckBox femaleCheckBox;

    @FXML
    private TextField placeOfBirthField;

    @FXML
    private TextField addressField;

    @FXML
    private TextField zipCodeField;

    @FXML
    private CheckBox singleCheckBox;

    @FXML
    private CheckBox marriedCheckBox;

    @FXML
    private TextField emailField;

    @FXML
    private TextField ageField;

    @FXML
    private TextField contactNumberField;

    @FXML
    private TextField emergencyNumberField;

    @FXML
    private Button nextButton;

    public void navigateToLoginScreen(ActionEvent event) throws IOException {
        String name = nameField.getText();
        String dateOfBirth = dateOfBirthPicker.getValue().toString(); // Use getValue() to get the selected date
        String gender = maleCheckBox.isSelected() ? "Male" : femaleCheckBox.isSelected() ? "Female" : "Not specified";
        String placeOfBirth = placeOfBirthField.getText();
        String address = addressField.getText();
        String zipCode = zipCodeField.getText();
        String maritalStatus = singleCheckBox.isSelected() ? "Single" : marriedCheckBox.isSelected() ? "Married" : "Not specified";
        String email = emailField.getText();
        String age = ageField.getText();
        String contactNumber = contactNumberField.getText();
        String emergencyNumber = emergencyNumberField.getText();

        // Process the data or perform any necessary actions

        // Navigate to the login screen (replace with the correct FXML file)
        Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene scene = new Scene(root);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

}
